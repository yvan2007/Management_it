# -*- coding: utf-8 -*-
from odoo import models, fields, api

class UserFinal(models.Model):
    _name = 'it.asset.user.final'
    _description = 'Utilisateur Final'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    client_id = fields.Many2one('it.asset.client', string='Client', required=True, tracking=True)
    department_id = fields.Many2one('it.asset.department', string='Département', tracking=True)
    email = fields.Char(string='Email', tracking=True)
    phone = fields.Char(string='Téléphone', tracking=True)
    equipment_ids = fields.One2many('it.asset.equipment', 'user_id', string='Équipements')
    active = fields.Boolean(string='Actif', default=True)