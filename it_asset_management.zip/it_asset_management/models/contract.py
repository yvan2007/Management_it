# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Contract(models.Model):
    _name = 'it.asset.contract'
    _description = 'Contrat de Service'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom du Contrat', required=True, tracking=True)
    reference = fields.Char(string='Référence', readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('it.asset.contract'))
    client_id = fields.Many2one('it.asset.client', string='Client', required=True, tracking=True)
    start_date = fields.Date(string='Date de Début', required=True, tracking=True)
    end_date = fields.Date(string='Date de Fin', tracking=True)
    terms = fields.Text(string='Termes du Contrat')
    pricing_model = fields.Selection([
        ('fixed', 'Forfait Fixe'),
        ('per_equipment', 'Par Équipement'),
        ('custom', 'Personnalisé'),
    ], string='Modèle de Tarification', required=True, default='fixed', tracking=True)
    billing_frequency = fields.Selection([
        ('monthly', 'Mensuelle'),
        ('quarterly', 'Trimestrielle'),
        ('annually', 'Annuelle'),
    ], string='Fréquence de Facturation', required=True, default='monthly', tracking=True)
    amount = fields.Float(string='Montant', required=True, tracking=True)
    invoice_ids = fields.One2many('account.move', 'contract_id', string='Factures')
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('active', 'Actif'),
        ('expired', 'Expiré'),
        ('cancelled', 'Annulé'),
    ], string='État', default='draft', tracking=True)
    sla_ids = fields.One2many('it.asset.sla', 'contract_id', string='SLA')

    @api.constrains('start_date', 'end_date')
    def _check_dates(self):
        for record in self:
            if record.end_date and record.start_date > record.end_date:
                raise ValidationError("La date de fin doit être postérieure à la date de début.")