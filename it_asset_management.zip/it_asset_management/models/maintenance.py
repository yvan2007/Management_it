# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Maintenance(models.Model):
    _name = 'it.asset.maintenance'
    _description = 'Maintenance Préventive'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    equipment_id = fields.Many2one('it.asset.equipment', string='Équipement', required=True, tracking=True)
    date_planned = fields.Date(string='Date Planifiée', required=True, tracking=True)
    date_executed = fields.Date(string='Date Exécutée', tracking=True)
    description = fields.Text(string='Description')
    technician_id = fields.Many2one('hr.employee', string='Technicien', tracking=True)
    status = fields.Selection([
        ('planned', 'Planifiée'),
        ('completed', 'Complétée'),
        ('cancelled', 'Annulée'),
    ], string='Statut', default='planned', tracking=True)