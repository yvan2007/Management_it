# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Technician(models.Model):
    _name = 'it.asset.technician'
    _description = 'Technicien'
    _inherit = 'hr.employee'

    intervention_ids = fields.One2many('it.asset.intervention', 'technician_id', string='Interventions')
    certification = fields.Char(string='Certification')
    availability = fields.Boolean(string='Disponible', default=True)