# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Amortization(models.Model):
    _name = 'it.asset.amortization'
    _description = 'Amortissement'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    equipment_id = fields.Many2one('it.asset.equipment', string='Équipement', required=True, tracking=True)
    method = fields.Selection([
        ('linear', 'Linéaire'),
        ('degressive', 'Dégressif'),
    ], string='Méthode', required=True, default='linear', tracking=True)
    duration = fields.Integer(string='Durée (mois)', required=True, tracking=True)
    start_date = fields.Date(string='Date de Début', required=True, tracking=True)
    purchase_value = fields.Float(string='Valeur d\'Achat', required=True, tracking=True)
    residual_value = fields.Float(string='Valeur Résiduelle', default=0.0, tracking=True)
    monthly_amortization = fields.Float(string='Amortissement Mensuel', compute='_compute_amortization', store=True)

    @api.depends('method', 'duration', 'purchase_value', 'residual_value')
    def _compute_amortization(self):
        for record in self:
            if record.method == 'linear' and record.duration > 0:
                record.monthly_amortization = (record.purchase_value - record.residual_value) / record.duration
            elif record.method == 'degressive':
                # Implémentation simplifiée pour l'exemple
                record.monthly_amortization = (record.purchase_value * 0.2) / 12
            else:
                record.monthly_amortization = 0.0