# -*- coding: utf-8 -*-
from odoo import models, fields, api

class EquipmentType(models.Model):
    _name = 'it.asset.equipment.type'
    _description = 'Type d\'Équipement'

    name = fields.Char(string='Nom', required=True)
    description = fields.Text(string='Description')
    code = fields.Char(string='Code', required=True)
    icon = fields.Binary(string='Icône')