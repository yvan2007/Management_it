# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Client(models.Model):
    _name = 'it.asset.client'
    _description = 'Client'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom du Client', required=True, tracking=True)
    address = fields.Text(string='Adresse', tracking=True)
    phone = fields.Char(string='Téléphone')
    email = fields.Char(string='Email')
    contact_ids = fields.Many2many('res.partner', string='Contacts')
    contract_ids = fields.One2many('it.asset.contract', 'client_id', string='Contrats')
    equipment_ids = fields.One2many('it.asset.equipment', 'client_id', string='Équipements')
    license_ids = fields.One2many('it.asset.license', 'client_id', string='Licences')
    site_ids = fields.One2many('it.asset.site', 'client_id', string='Sites')
    department_ids = fields.One2many('it.asset.department', 'client_id', string='Départements')
    notes = fields.Text(string='Notes')
    active = fields.Boolean(string='Actif', default=True)

    @api.model
    def create(self, vals):
        res = super(Client, self).create(vals)
        res.message_subscribe(partner_ids=[res.env.user.partner_id.id])
        return res