# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Site(models.Model):
    _name = 'it.asset.site'
    _description = 'Site Géographique'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    client_id = fields.Many2one('it.asset.client', string='Client', required=True, tracking=True)
    address = fields.Text(string='Adresse', tracking=True)
    contact_person = fields.Char(string='Personne de Contact', tracking=True)
    equipment_ids = fields.One2many('it.asset.equipment', 'site_id', string='Équipements')
    department_ids = fields.One2many('it.asset.department', 'site_id', string='Départements')