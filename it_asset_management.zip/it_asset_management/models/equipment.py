# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Equipment(models.Model):
    _name = 'it.asset.equipment'
    _description = 'Équipement'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    equipment_type_id = fields.Many2one('it.asset.equipment.type', string='Type', required=True, tracking=True)
    serial_number = fields.Char(string='Numéro de Série', tracking=True)
    purchase_date = fields.Date(string='Date d\'Achat', tracking=True)
    warranty_end_date = fields.Date(string='Fin de Garantie', tracking=True)
    client_id = fields.Many2one('it.asset.client', string='Client', required=True, tracking=True)
    user_id = fields.Many2one('it.asset.user.final', string='Utilisateur Final', tracking=True)
    site_id = fields.Many2one('it.asset.site', string='Site', tracking=True)
    department_id = fields.Many2one('it.asset.department', string='Département', tracking=True)
    supplier_id = fields.Many2one('it.asset.supplier', string='Fournisseur', tracking=True)
    maintenance_ids = fields.One2many('it.asset.maintenance', 'equipment_id', string='Maintenances')
    incident_ids = fields.One2many('it.asset.incident', 'equipment_id', string='Incidents')
    amortization_ids = fields.One2many('it.asset.amortization', 'equipment_id', string='Amortissements')
    state = fields.Selection([
        ('active', 'Actif'),
        ('maintenance', 'En Maintenance'),
        ('retired', 'Retiré'),
    ], string='État', default='active', tracking=True)
    image = fields.Binary(string='Image')

    @api.onchange('client_id')
    def _onchange_client_id(self):
        self.site_id = False
        self.department_id = False
        return {'domain': {'site_id': [('client_id', '=', self.client_id.id)], 'department_id': [('client_id', '=', self.client_id.id)]}}