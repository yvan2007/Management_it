# -*- coding: utf-8 -*-
from odoo import models, fields, api

class License(models.Model):
    _name = 'it.asset.license'
    _description = 'Licence Logicielle'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    client_id = fields.Many2one('it.asset.client', string='Client', required=True, tracking=True)
    software_name = fields.Char(string='Nom du Logiciel', required=True, tracking=True)
    expiration_date = fields.Date(string='Date d\'Expiration', tracking=True)
    license_key = fields.Char(string='Clé de Licence', tracking=True)
    equipment_ids = fields.Many2many('it.asset.equipment', string='Équipements Associés')
    state = fields.Selection([
        ('active', 'Active'),
        ('expired', 'Expirée'),
        ('cancelled', 'Annulée'),
    ], string='État', default='active', tracking=True)

    @api.constrains('expiration_date')
    def _check_expiration(self):
        for record in self:
            if record.expiration_date and record.expiration_date < fields.Date.today():
                record.state = 'expired'