# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Supplier(models.Model):
    _name = 'it.asset.supplier'
    _description = 'Fournisseur'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    contact = fields.Char(string='Contact', tracking=True)
    email = fields.Char(string='Email', tracking=True)
    phone = fields.Char(string='Téléphone', tracking=True)
    equipment_ids = fields.One2many('it.asset.equipment', 'supplier_id', string='Équipements')
    active = fields.Boolean(string='Actif', default=True)