# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Warranty(models.Model):
    _name = 'it.asset.warranty'
    _description = 'Garantie'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    equipment_id = fields.Many2one('it.asset.equipment', string='Équipement', required=True, tracking=True)
    start_date = fields.Date(string='Date de Début', required=True, tracking=True)
    end_date = fields.Date(string='Date de Fin', required=True, tracking=True)
    terms = fields.Text(string='Termes de la Garantie')
    supplier_id = fields.Many2one('it.asset.supplier', string='Fournisseur', tracking=True)
    state = fields.Selection([
        ('active', 'Active'),
        ('expired', 'Expirée'),
    ], string='État', default='active', tracking=True)

    @api.constrains('end_date')
    def _check_expiration(self):
        for record in self:
            if record.end_date < fields.Date.today():
                record.state = 'expired'