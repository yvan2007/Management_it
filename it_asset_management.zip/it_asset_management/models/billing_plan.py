# -*- coding: utf-8 -*-
from odoo import models, fields, api

class BillingPlan(models.Model):
    _name = 'it.asset.billing.plan'
    _description = 'Plan de Facturation'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    contract_id = fields.Many2one('it.asset.contract', string='Contrat', required=True, tracking=True)
    frequency = fields.Selection([
        ('monthly', 'Mensuelle'),
        ('quarterly', 'Trimestrielle'),
        ('annually', 'Annuelle'),
    ], string='Fréquence', required=True, default='monthly', tracking=True)
    next_invoice_date = fields.Date(string='Prochaine Date de Facturation', required=True, tracking=True)
    amount = fields.Float(string='Montant', required=True, tracking=True)
    invoice_ids = fields.One2many('account.move', 'billing_plan_id', string='Factures')

    def _generate_invoices(self):
        today = fields.Date.today()
        plans = self.search([('next_invoice_date', '<=', today)])
        for plan in plans:
            invoice = self.env['account.move'].create({
                'move_type': 'out_invoice',
                'partner_id': plan.contract_id.client_id.id,
                'contract_id': plan.contract_id.id,
                'billing_plan_id': plan.id,
                'invoice_line_ids': [(0, 0, {
                    'name': f"Facture pour {plan.contract_id.name}",
                    'quantity': 1,
                    'price_unit': plan.amount,
                })],
            })
            invoice.action_post()
            plan.next_invoice_date = self._get_next_date(plan.next_invoice_date, plan.frequency)

    def _get_next_date(self, current_date, frequency):
        if frequency == 'monthly':
            return current_date + relativedelta(months=1)
        elif frequency == 'quarterly':
            return current_date + relativedelta(months=3)
        elif frequency == 'annually':
            return current_date + relativedelta(years=1)
        return current_date