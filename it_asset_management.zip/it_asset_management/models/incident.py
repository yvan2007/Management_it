# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Incident(models.Model):
    _name = 'it.asset.incident'
    _description = 'Incident'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    reference = fields.Char(string='Référence', readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('it.asset.incident'))
    date = fields.Date(string='Date', required=True, default=fields.Date.today, tracking=True)
    equipment_id = fields.Many2one('it.asset.equipment', string='Équipement', required=True, tracking=True)
    description = fields.Text(string='Description')
    priority = fields.Selection([
        ('low', 'Faible'),
        ('medium', 'Moyen'),
        ('high', 'Élevé'),
    ], string='Priorité', default='medium', tracking=True)
    status = fields.Selection([
        ('open', 'Ouvert'),
        ('in_progress', 'En Cours'),
        ('resolved', 'Résolu'),
        ('closed', 'Clôturé'),
    ], string='Statut', default='open', tracking=True)
    resolution_date = fields.Date(string='Date de Résolution', tracking=True)
    resolution = fields.Text(string='Résolution')