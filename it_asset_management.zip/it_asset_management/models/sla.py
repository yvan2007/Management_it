# -*- coding: utf-8 -*-
from odoo import models, fields, api

class SLA(models.Model):
    _name = 'it.asset.sla'
    _description = 'Accord de Niveau de Service'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    contract_id = fields.Many2one('it.asset.contract', string='Contrat', required=True, tracking=True)
    response_time = fields.Float(string='Temps de Réponse (heures)', required=True, tracking=True)
    resolution_time = fields.Float(string='Temps de Résolution (heures)', required=True, tracking=True)
    priority = fields.Selection([
        ('low', 'Faible'),
        ('medium', 'Moyen'),
        ('high', 'Élevé'),
    ], string='Priorité', required=True, default='medium', tracking=True)
    active = fields.Boolean(string='Actif', default=True, tracking=True)