# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Department(models.Model):
    _name = 'it.asset.department'
    _description = 'Département'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    client_id = fields.Many2one('it.asset.client', string='Client', required=True, tracking=True)
    site_id = fields.Many2one('it.asset.site', string='Site', tracking=True)
    manager = fields.Char(string='Responsable', tracking=True)
    user_ids = fields.One2many('it.asset.user.final', 'department_id', string='Utilisateurs')
    equipment_ids = fields.One2many('it.asset.equipment', 'department_id', string='Équipements')