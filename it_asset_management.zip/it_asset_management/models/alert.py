# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Alert(models.Model):
    _name = 'it.asset.alert'
    _description = 'Alerte'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    alert_type = fields.Selection([
        ('license_expiration', 'Expiration de Licence'),
        ('warranty_expiration', 'Expiration de Garantie'),
        ('maintenance_due', 'Maintenance Due'),
        ('custom', 'Personnalisée'),
    ], string='Type d\'Alerte', required=True, tracking=True)
    date = fields.Date(string='Date', required=True, tracking=True)
    description = fields.Text(string='Description')
    related_id = fields.Reference([
        ('it.asset.license', 'Licence'),
        ('it.asset.equipment', 'Équipement'),
        ('it.asset.maintenance', 'Maintenance'),
    ], string='Relatif à', tracking=True)
    state = fields.Selection([
        ('pending', 'En Attente'),
        ('notified', 'Notifiée'),
        ('resolved', 'Résolue'),
    ], string='État', default='pending', tracking=True)

    def _check_alerts(self):
        today = fields.Date.today()
        upcoming_alerts = self.search([
            ('date', '<=', today + relativedelta(days=30)),
            ('state', '=', 'pending')
        ])
        for alert in upcoming_alerts:
            alert.state = 'notified'
            alert.message_post(body=f"Alerte {alert.name} notifiée.")