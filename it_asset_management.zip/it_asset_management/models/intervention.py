# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Intervention(models.Model):
    _name = 'it.asset.intervention'
    _description = 'Intervention Technique'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Nom', required=True, tracking=True)
    reference = fields.Char(string='Référence', readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('it.asset.intervention'))
    date = fields.Date(string='Date', required=True, default=fields.Date.today, tracking=True)
    technician_id = fields.Many2one('hr.employee', string='Technicien', required=True, tracking=True)
    equipment_id = fields.Many2one('it.asset.equipment', string='Équipement', required=True, tracking=True)
    description = fields.Text(string='Description')
    duration = fields.Float(string='Durée (heures)', tracking=True)
    state = fields.Selection([
        ('planned', 'Planifiée'),
        ('in_progress', 'En Cours'),
        ('completed', 'Terminée'),
    ], string='État', default='planned', tracking=True)