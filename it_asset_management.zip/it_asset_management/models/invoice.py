# -*- coding: utf-8 -*-
from odoo import models, fields, api

class Invoice(models.Model):
    _inherit = 'account.move'

    contract_id = fields.Many2one('it.asset.contract', string='Contrat')
    equipment_ids = fields.Many2many('it.asset.equipment', string='Équipements Facturés')