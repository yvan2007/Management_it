odoo.define('it_asset_management.portal', function (require) {
    "use strict";
    var publicWidget = require('web.public.widget');

    publicWidget.registry.AssetPortal = publicWidget.Widget.extend({
        selector: '.card-body',
        events: {
            'click': '_onCardClick',
        },
        _onCardClick: function (ev) {
            console.log('Équipement cliqué !');
        },
    });
});