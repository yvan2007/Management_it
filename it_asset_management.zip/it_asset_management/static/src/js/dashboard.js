odoo.define('it_asset_management.dashboard', function (require) {
    "use strict";
    var core = require('web.core');
    var Widget = require('web.Widget');

    var Dashboard = Widget.extend({
        template: 'it_asset_management.DashboardTemplate',
        init: function () {
            this._super.apply(this, arguments);
        },
    });

    core.action_registry.add('it_asset_management.dashboard', Dashboard);
});