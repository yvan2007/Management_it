# -*- coding: utf-8 -*-
from odoo import models, fields, api
import csv
import base64
from io import StringIO

class EquipmentImport(models.TransientModel):
    _name = 'it.asset.equipment.import'
    _description = 'Importation d\'Équipements'

    file = fields.Binary(string='Fichier CSV', required=True)
    filename = fields.Char(string='Nom du Fichier')

    def import_equipments(self):
        if not self.file:
            raise ValidationError("Aucun fichier fourni.")
        file_data = base64.b64decode(self.file).decode('utf-8')
        csv_file = StringIO(file_data)
        reader = csv.DictReader(csv_file)
        for row in reader:
            self.env['it.asset.equipment'].create({
                'name': row['name'],
                'equipment_type_id': self.env['it.asset.equipment.type'].search([('code', '=', row['type_code'])], limit=1).id,
                'serial_number': row['serial_number'],
                'client_id': self.env['it.asset.client'].search([('name', '=', row['client'])], limit=1).id,
            })
        return {'type': 'ir.actions.act_window_close'}