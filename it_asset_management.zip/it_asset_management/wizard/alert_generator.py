# -*- coding: utf-8 -*-
from odoo import models, fields, api

class AlertGenerator(models.TransientModel):
    _name = 'it.asset.alert.generator'
    _description = 'Générateur d\'Alertes'

    name = fields.Char(string='Nom', required=True)
    alert_type = fields.Selection([
        ('license_expiration', 'Expiration de Licence'),
        ('warranty_expiration', 'Expiration de Garantie'),
        ('maintenance_due', 'Maintenance Due'),
        ('custom', 'Personnalisée'),
    ], string='Type d\'Alerte', required=True)
    date = fields.Date(string='Date', required=True)
    description = fields.Text(string='Description')
    related_id = fields.Reference([
        ('it.asset.license', 'Licence'),
        ('it.asset.equipment', 'Équipement'),
        ('it.asset.maintenance', 'Maintenance'),
    ], string='Relatif à')

    def generate_alert(self):
        self.env['it.asset.alert'].create({
            'name': self.name,
            'alert_type': self.alert_type,
            'date': self.date,
            'description': self.description,
            'related_id': self.related_id,
        })
        return {'type': 'ir.actions.act_window_close'}