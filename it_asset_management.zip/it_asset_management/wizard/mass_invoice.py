# -*- coding: utf-8 -*-
from odoo import models, fields, api

class MassInvoice(models.TransientModel):
    _name = 'it.asset.mass.invoice'
    _description = 'Facturation en Masse'

    contract_ids = fields.Many2many('it.asset.contract', string='Contrats')

    def generate_invoices(self):
        for contract in self.contract_ids:
            self.env['account.move'].create({
                'move_type': 'out_invoice',
                'partner_id': contract.client_id.id,
                'contract_id': contract.id,
                'invoice_line_ids': [(0, 0, {
                    'name': f"Facture pour {contract.name}",
                    'quantity': 1,
                    'price_unit': contract.amount,
                })],
            }).action_post()
        return {'type': 'ir.actions.act_window_close'}