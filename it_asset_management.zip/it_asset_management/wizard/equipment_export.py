# -*- coding: utf-8 -*-
from odoo import models, fields, api
import csv
from io import StringIO

class EquipmentExport(models.TransientModel):
    _name = 'it.asset.equipment.export'
    _description = 'Exportation d\'Équipements'

    def export_equipments(self):
        equipments = self.env['it.asset.equipment'].search([])
        output = StringIO()
        writer = csv.writer(output)
        writer.writerow(['name', 'type_code', 'serial_number', 'client'])
        for eq in equipments:
            writer.writerow([
                eq.name,
                eq.equipment_type_id.code,
                eq.serial_number,
                eq.client_id.name,
            ])
        output.seek(0)
        file_data = base64.b64encode(output.read().encode('utf-8'))
        return {
            'type': 'ir.actions.act_url',
            'url': 'data:application/csv;base64,' + file_data.decode('utf-8'),
            'target': 'self',
        }