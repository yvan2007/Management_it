# -*- coding: utf-8 -*-
from odoo import models, fields, api

class ContractRenewal(models.TransientModel):
    _name = 'it.asset.contract.renewal'
    _description = 'Renouvellement de Contrat'

    contract_id = fields.Many2one('it.asset.contract', string='Contrat', required=True)
    new_end_date = fields.Date(string='Nouvelle Date de Fin', required=True)

    def renew_contract(self):
        self.contract_id.write({
            'end_date': self.new_end_date,
            'state': 'active',
        })
        return {'type': 'ir.actions.act_window_close'}