# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

class PortalController(http.Controller):

    @http.route('/my/assets', type='http', auth='user', website=True)
    def my_assets(self, **kwargs):
        client = request.env.user.partner_id.client_id
        equipments = request.env['it.asset.equipment'].search([('client_id', '=', client.id)])
        return request.render('it_asset_management.portal_my_assets', {'equipments': equipments})

    @http.route('/my/incidents', type='http', auth='user', website=True)
    def my_incidents(self, **kwargs):
        client = request.env.user.partner_id.client_id
        incidents = request.env['it.asset.incident'].search([('equipment_id.client_id', '=', client.id)])
        return request.render('it_asset_management.portal_my_incidents', {
            'incidents': incidents,
        })