# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request

class APIController(http.Controller):

    @http.route('/api/equipments', type='json', auth='public', methods=['GET'])
    def get_equipments(self):
        equipments = request.env['it.asset.equipment'].search_read([], ['name', 'serial_number', 'client_id'])
        return equipments

    @http.route('/api/incidents', type='json', auth='user', methods=['POST'])
    def create_incident(self, equipment_id, description):
        incident = request.env['it.asset.incident'].create({
            'name': 'Incident API',
            'equipment_id': equipment_id,
            'description': description,
            'status': 'open',
        })
        return {'incident_id': incident.id}